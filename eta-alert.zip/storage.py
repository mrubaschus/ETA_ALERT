"""KV storage — Samsara persistent Database in hosted mode, local JSON fallback.

When running inside Samsara Functions (SamsaraFunctionStorageName env var is set),
uses the official `samsarafnstorage.Database` backed by S3 so state survives cold
starts.  Locally (no env var), falls back to a JSON file next to this script.
"""

import json
import os
from pathlib import Path
from typing import Any, Optional

# ---------------------------------------------------------------------------
# Samsara persistent Database (S3-backed, survives cold starts)
# ---------------------------------------------------------------------------
_samsara_db = None  # lazy singleton


def _use_samsara_storage() -> bool:
    """True when running inside Samsara Functions with storage configured."""
    return bool(os.getenv("SamsaraFunctionStorageName"))


def _get_samsara_db():
    global _samsara_db
    if _samsara_db is not None:
        return _samsara_db
    try:
        from samsarafnstorage import get_database
        _samsara_db = get_database("eta-alert")
        return _samsara_db
    except Exception as exc:
        print(f"[WARN] Failed to init Samsara Database: {type(exc).__name__}: {exc}")
        return None


# ---------------------------------------------------------------------------
# Local JSON fallback (development / non-Samsara runtimes)
# ---------------------------------------------------------------------------

def _default_storage_path() -> str:
    explicit = os.getenv("FUNCTION_STORAGE_PATH")
    if explicit:
        return explicit
    return str(Path(__file__).with_name(".function_storage.json"))


def _resolve_storage_path(storage_path: Optional[str]) -> str:
    return storage_path or _default_storage_path()


def _load_all(path: str) -> dict[str, Any]:
    p = Path(path)
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_all(path: str, data: dict[str, Any]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")


# ---------------------------------------------------------------------------
# Public API  (unchanged signatures — get_item / set_item / delete_item)
# ---------------------------------------------------------------------------

def get_item(key: str, *, storage_path: Optional[str] = None) -> Optional[dict[str, Any]]:
    if _use_samsara_storage():
        db = _get_samsara_db()
        if db is not None:
            try:
                return db.get_dict(key)
            except Exception:
                return None
    # local fallback
    path = _resolve_storage_path(storage_path)
    data = _load_all(path)
    value = data.get(key)
    return value if isinstance(value, dict) else None


def set_item(key: str, value: dict[str, Any], *, storage_path: Optional[str] = None) -> None:
    if _use_samsara_storage():
        db = _get_samsara_db()
        if db is not None:
            try:
                db.put_dict(key, value)
                return
            except Exception as exc:
                print(f"[WARN] Samsara DB put failed for {key}: {type(exc).__name__}: {exc}")
    # local fallback
    path = _resolve_storage_path(storage_path)
    data = _load_all(path)
    data[key] = value
    _save_all(path, data)


def delete_item(key: str, *, storage_path: Optional[str] = None) -> None:
    if _use_samsara_storage():
        db = _get_samsara_db()
        if db is not None:
            try:
                db.delete(key)
                return
            except Exception:
                pass
    # local fallback
    path = _resolve_storage_path(storage_path)
    data = _load_all(path)
    if key in data:
        del data[key]
        _save_all(path, data)
